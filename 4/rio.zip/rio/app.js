var rio = require("rio");

var options = {
    host: "192.168.1.201",//"127.0.0.1",
    port: 6311,
    callback: function (err, val) {
        if (err) {
            console.log("ERROR");
            return;
        }
        console.log(val);
    }
}

//rio.enableDebug(true);//开启调试模式
function eva(rscript){
    console.log("> "+rscript);
    rio.evaluate(rscript, options);//运行R代码
}


//eva("pi / 2 * 2 * 2");
//eva("data.frame(a=rnorm(10),b=seq(1:10))");


eva("a=pi / 2 * 2");
eva("b\<-c(1, 2)");
eva("c<-as.character('Hello World')");
eva("d<-c('a', 'b')");
eva("e<-data.frame(a=rnorm(10),b=seq(1:10))");

eva("ls()");
eva("c");

//rio.evaluate('Sys.sleep(5); 11')



//rio.evaluate("pi / 2 * 2 * 2", options);//运行R代码
//rio.evaluate("data.frame(a=rnorm(10),b=seq(1:10))",options);
//rio.evaluate("a",options);